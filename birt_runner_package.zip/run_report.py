import os
import subprocess
import xml.etree.ElementTree as ET
import pandas as pd

BIRT_HOME = "birt-runtime/ReportEngine"
JAVA_JAR = "report_executor.jar"
XML_DIR = "testcases"
OUTPUT_DIR = "outputs"
LOG_FILE = "logs/report_log.xlsx"

os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs("logs", exist_ok=True)

logs = []

for xml_file in os.listdir(XML_DIR):
    if not xml_file.endswith(".xml"):
        continue

    tree = ET.parse(os.path.join(XML_DIR, xml_file))
    root = tree.getroot()

    rpt_path = root.find("ReportName").text.strip()
    format = root.find("Format").text.strip().lower()

    params = []
    for p in root.findall(".//Parameter"):
        name = p.attrib["name"]
        value = p.text.strip()
        params.extend([name, value])

    out_filename = os.path.splitext(os.path.basename(rpt_path))[0] + f"_{xml_file.replace('.xml','')}.{format}"
    out_path = os.path.join(OUTPUT_DIR, out_filename)

    cmd = ["java", "-cp", f"{JAVA_JAR};{BIRT_HOME}/lib/*", "ReportExecutor",
           BIRT_HOME, rpt_path, format, out_path] + params

    print(f"Running {xml_file} -> {out_filename}")
    result = subprocess.run(cmd, capture_output=True, text=True)

    status = "SUCCESS" if "SUCCESS" in result.stdout else "FAILED"
    error = result.stdout if status == "FAILED" else ""

    logs.append({
        "Testcase XML": xml_file,
        "Report": rpt_path,
        "Format": format,
        "Output": out_path if status == "SUCCESS" else "",
        "Status": status,
        "Error": error.strip()
    })

df = pd.DataFrame(logs)
df.to_excel(LOG_FILE, index=False)
print(f"\nDone. Log written to {LOG_FILE}")