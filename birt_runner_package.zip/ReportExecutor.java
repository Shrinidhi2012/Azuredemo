import java.io.File;
import java.util.HashMap;
import java.util.Map;
import org.eclipse.birt.core.framework.Platform;
import org.eclipse.birt.report.engine.api.*;

public class ReportExecutor {
    public static void main(String[] args) {
        try {
            String birtHome = args[0];
            String rptdesign = args[1];
            String format = args[2];
            String outputPath = args[3];

            Map<String, Object> params = new HashMap<>();
            for (int i = 4; i < args.length; i += 2) {
                params.put(args[i], args[i + 1]);
            }

            EngineConfig config = new EngineConfig();
            config.setEngineHome(birtHome);
            Platform.startup(config);
            IReportEngineFactory factory = (IReportEngineFactory) Platform.createFactoryObject(
                    IReportEngineFactory.EXTENSION_REPORT_ENGINE_FACTORY);
            IReportEngine engine = factory.createReportEngine(config);

            IReportRunnable design = engine.openReportDesign(rptdesign);
            IRunAndRenderTask task = engine.createRunAndRenderTask(design);
            task.setParameterValues(params);
            task.validateParameters();

            IRenderOption options = null;

            if (format.equalsIgnoreCase("pdf")) {
                PDFRenderOption pdf = new PDFRenderOption();
                pdf.setOutputFormat("pdf");
                pdf.setOutputFileName(outputPath);
                options = pdf;
            } else if (format.equalsIgnoreCase("xls") || format.equalsIgnoreCase("xlsx")) {
                EXCELRenderOption excel = new EXCELRenderOption();
                excel.setOutputFormat("xls");
                excel.setOutputFileName(outputPath);
                options = excel;
            }

            task.setRenderOption(options);
            task.run();
            task.close();
            engine.destroy();
            Platform.shutdown();

            System.out.println("SUCCESS");
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }
}